package starter_files;

import java.util.ArrayList;

public class HuffmanTree {
	TreeNode root;
	
	HuffmanTree() {
		root = null;
	}
	
	public void constructHuffmanTree(ArrayList<String> characters, ArrayList<Integer> freq) {

	}
	
	public String encode(String humanMessage) {
	    return "";
	}
	
	public String decode(String encodedMessage) {
        return "";
	}
}
